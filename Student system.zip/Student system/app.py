from flask import Flask, render_template, request, redirect, session, url_for, flash
import sqlite3

app = Flask(__name__)
app.secret_key = 'super_secret_key_for_sessions'

def get_db_connection():
    conn = sqlite3.connect('students.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            password TEXT NOT NULL,
            role TEXT NOT NULL
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS students (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            gender TEXT,
            department TEXT,
            class TEXT,
            email TEXT,
            phone TEXT,
            english INTEGER DEFAULT 0,
            computer INTEGER DEFAULT 0,
            maths INTEGER DEFAULT 0,
            physics INTEGER DEFAULT 0,
            chemistry INTEGER DEFAULT 0,
            FOREIGN KEY (id) REFERENCES users (username) ON DELETE CASCADE
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS teachers (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            department TEXT,
            class TEXT,
            email TEXT,
            phone TEXT,
            status TEXT DEFAULT 'Active',
            FOREIGN KEY (id) REFERENCES users (username) ON DELETE CASCADE
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS announcements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            date_added TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute("SELECT COUNT(*) FROM users")
    if cursor.fetchone()[0] == 0:
        cursor.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", ('admin', 'admin123', 'admin'))
        cursor.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", ('teacher', 'teacher123', 'teacher'))
        cursor.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", ('student', 'student123', 'student'))
        
        cursor.execute("INSERT INTO teachers (id, name, department, class, email, phone, status) VALUES (?, ?, ?, ?, ?, ?, ?)",
                       ('teacher', 'Default Teacher', 'Computer Science', 'Class A', 'teacher@school.com', '1234567890', 'Active'))
        cursor.execute("INSERT INTO students (id, name, gender, department, class, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?)",
                       ('student', 'Default Student', 'Male', 'Science', 'Class A', 'student@school.com', '0987654321'))
        
    conn.commit()
    conn.close()

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user_id = request.form['user_id']
        password = request.form['password']
        role = request.form['role']
        
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ? AND password = ? AND role = ?', 
                            (user_id, password, role)).fetchone()
        conn.close()
        
        if user:
            session['role'] = user['role']
            session['username'] = user['username']
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid Credentials from Database! Please try again.', 'danger')
            
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if 'role' not in session:
        return redirect(url_for('login'))
        
    role = session['role']
    search_query = request.args.get('search', '')
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # ─── REAL-TIME SYSTEM COUNTS ACCORDING TO YOUR REQUEST ───
    total_students = cursor.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    active_teachers = cursor.execute("SELECT COUNT(*) FROM teachers WHERE status = 'Active'").fetchone()[0]
    total_notices = cursor.execute("SELECT COUNT(*) FROM announcements").fetchone()[0]
    
    if search_query:
        cursor.execute("SELECT * FROM students WHERE id LIKE ? OR name LIKE ?", (f'%{search_query}%', f'%{search_query}%'))
    else:
        cursor.execute("SELECT * FROM students")
    students = cursor.fetchall()
    
    cursor.execute("SELECT * FROM announcements ORDER BY id DESC")
    announcements = cursor.fetchall()
    
    cursor.execute("SELECT * FROM teachers")
    teachers = cursor.fetchall()
    
    conn.close()
    
    return render_template('dashboard.html', 
                           role=role, 
                           students=students, 
                           announcements=announcements, 
                           teachers=teachers, 
                           search_query=search_query,
                           total_students=total_students,      
                           active_teachers=active_teachers,    
                           total_notices=total_notices)

@app.route('/add_student', methods=['POST'])
def add_student():
    if session.get('role') not in ['admin', 'teacher']: return "Unauthorized", 403
    
    student_id = request.form['id']
    conn = get_db_connection()
    try:
        conn.execute('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', (student_id, 'password123', 'student'))
        conn.execute('''
            INSERT INTO students (id, name, gender, department, class, email, phone)
            VALUES (?, ?, ?, ?, ?, ?, ?)''', 
            (student_id, request.form['name'], request.form['gender'], 
             request.form['department'], request.form['class'], request.form['email'], request.form['phone'])
        )
        conn.commit()
    except sqlite3.IntegrityError:
        flash('User account / Student ID already exists!', 'danger')
    conn.close()
    return redirect(url_for('dashboard'))

@app.route('/edit_student/<id>', methods=['POST'])
def edit_student(id):
    if session.get('role') not in ['admin', 'teacher']: return "Unauthorized", 403
    
    conn = get_db_connection()
    conn.execute('''
        UPDATE students SET name=?, gender=?, department=?, class=?, email=?, phone=? 
        WHERE id=?''',
        (request.form['name'], request.form['gender'], request.form['department'], 
         request.form['class'], request.form['email'], request.form['phone'], id)
    )
    conn.commit()
    conn.close()
    return redirect(url_for('dashboard'))

@app.route('/update_marks/<id>', methods=['POST'])
def update_marks(id):
    if session.get('role') != 'teacher': return "Unauthorized", 403
    
    conn = get_db_connection()
    conn.execute('''
        UPDATE students SET english=?, computer=?, maths=?, physics=?, chemistry=? 
        WHERE id=?''',
        (request.form['english'], request.form['computer'], request.form['maths'], 
         request.form['physics'], request.form['chemistry'], id)
    )
    conn.commit()
    conn.close()
    return redirect(url_for('dashboard'))

@app.route('/delete_student/<id>')
def delete_student(id):
    if session.get('role') not in ['admin', 'teacher']: return "Unauthorized", 403
    
    conn = get_db_connection()
    conn.execute('DELETE FROM users WHERE username = ?', (id,))
    conn.execute('DELETE FROM students WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('dashboard'))

@app.route('/add_teacher', methods=['POST'])
def add_teacher():
    if session.get('role') != 'admin': return "Unauthorized", 403
        
    teacher_id = request.form['id']
    conn = get_db_connection()
    try:
        conn.execute('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', (teacher_id, 'teacher123', 'teacher'))
        conn.execute('''
            INSERT INTO teachers (id, name, department, class, email, phone, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)''', 
            (teacher_id, request.form['name'], request.form['department'], 
             request.form['class'], request.form['email'], request.form['phone'], request.form['status'])
        )
        conn.commit()
    except sqlite3.IntegrityError:
        flash('User account / Teacher ID already exists!', 'danger')
    conn.close()
    return redirect(url_for('dashboard'))

@app.route('/edit_teacher/<id>', methods=['POST'])
def edit_teacher(id):
    if session.get('role') != 'admin': return "Unauthorized", 403
        
    conn = get_db_connection()
    conn.execute('''
        UPDATE teachers SET name=?, department=?, class=?, email=?, phone=?, status=? 
        WHERE id=?''',
        (request.form['name'], request.form['department'], request.form['class'], 
         request.form['email'], request.form['phone'], request.form['status'], id)
    )
    conn.commit()
    conn.close()
    return redirect(url_for('dashboard'))

@app.route('/add_announcement', methods=['POST'])
def add_announcement():
    if session.get('role') != 'admin': return "Unauthorized", 403
    
    conn = get_db_connection()
    conn.execute('INSERT INTO announcements (title, content) VALUES (?, ?)', 
                 (request.form['title'], request.form['content']))
    conn.commit()
    conn.close()
    return redirect(url_for('dashboard'))

@app.route('/report_card/<id>')
def report_card(id):
    conn = get_db_connection()
    student = conn.execute('SELECT * FROM students WHERE id = ?', (id,)).fetchone()
    conn.close()
    
    if not student: return "Student Not Found", 404
        
    total_marks = student['english'] + student['computer'] + student['maths'] + student['physics'] + student['chemistry']
    percentage = (total_marks / 500) * 100
    
    return render_template('report_card.html', student=student, total=total_marks, percentage=percentage)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
    